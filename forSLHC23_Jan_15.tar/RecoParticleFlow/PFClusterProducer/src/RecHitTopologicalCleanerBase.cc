#include "RecoParticleFlow/PFClusterProducer/interface/RecHitTopologicalCleanerBase.h"

EDM_REGISTER_PLUGINFACTORY(RecHitTopologicalCleanerFactory,
			   "RecHitTopologicalCleanerFactory");
