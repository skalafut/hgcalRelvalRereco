#include "RecoParticleFlow/PFClusterProducer/interface/PFCPositionCalculatorBase.h"

EDM_REGISTER_PLUGINFACTORY(PFCPositionCalculatorFactory,
			   "PFCPositionCalculatorFactory");
