#include "RecoParticleFlow/PFClusterProducer/interface/SeedFinderBase.h"

EDM_REGISTER_PLUGINFACTORY(SeedFinderFactory,"SeedFinderFactory");
