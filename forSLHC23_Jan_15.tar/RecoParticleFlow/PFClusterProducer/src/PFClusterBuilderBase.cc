#include "RecoParticleFlow/PFClusterProducer/interface/PFClusterBuilderBase.h"

EDM_REGISTER_PLUGINFACTORY(PFClusterBuilderFactory,
			   "PFClusterBuilderFactory");
