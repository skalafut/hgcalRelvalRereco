#include "RecoParticleFlow/PFClusterProducer/interface/InitialClusteringStepBase.h"

EDM_REGISTER_PLUGINFACTORY(InitialClusteringStepFactory,
			   "InitialClusteringStepFactory");
