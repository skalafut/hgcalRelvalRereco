#include "RecoParticleFlow/PFClusterProducer/interface/PFClusterEnergyCorrectorBase.h"

EDM_REGISTER_PLUGINFACTORY(PFClusterEnergyCorrectorFactory,
			   "PFClusterEnergyCorrectorFactory");
