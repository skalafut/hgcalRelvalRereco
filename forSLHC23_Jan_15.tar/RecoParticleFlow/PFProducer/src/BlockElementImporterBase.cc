#include "RecoParticleFlow/PFProducer/interface/BlockElementImporterBase.h"

EDM_REGISTER_PLUGINFACTORY(BlockElementImporterFactory,
			   "BlockElementImporterFactory");
