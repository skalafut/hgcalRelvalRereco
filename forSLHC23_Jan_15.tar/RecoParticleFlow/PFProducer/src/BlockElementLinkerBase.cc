#include "RecoParticleFlow/PFProducer/interface/BlockElementLinkerBase.h"

EDM_REGISTER_PLUGINFACTORY(BlockElementLinkerFactory,
			   "BlockElementLinkerFactory");
