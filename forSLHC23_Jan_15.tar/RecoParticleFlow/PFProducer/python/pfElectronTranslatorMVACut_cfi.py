import FWCore.ParameterSet.Config as cms

pfElecMva = cms.PSet(
    MVACut = cms.double(-1.)
    )
